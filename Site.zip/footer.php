        <footer>
            <div class="footerBas"><? echo $sunucu_ismi ?> » Tüm Hakları Saklı ve Korunma Altındadır! » <? echo date('Y') ?> ©</div>
            <div class="footerSon">
                <div class="footerBas"><font size=2>» LeaderOS v2.9</div>
            </div>
        </footer>
		
		<script src="js/swiper.min.js"></script>
		