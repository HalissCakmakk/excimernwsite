﻿<?php

	include ('../ayarlar/ayar.php');	

	include ('../head.php');

?>
<body>
	<?php
		include('../logo.php');
	?>
    <div id="wrapper">
		<?php
			include ('../header.php');
		?>
        <div id="sol">
            <div class="icBaslik"><div class="icBaslikYazi"><i class="fa fa-file-text fa-3x"></i><font size="6"> KURALLAR</font></div></div>
            <div class="ic">
                <div class="indir">
                    <br>
                        <font face="Oswald" color="blue"><u><strong>Sunucumuzdaki Her Oyuncu Bu Kurallari Kabul Etmis ve Okumus Sayilacaktir!</strong></u></font></p>
						<br>
						<font face="Oswald" color="red">Kaybolan veya yok olan hiçbir şeyden MineTC sorumlu değildir ve geri iadesi yapılmayacaktır.</font></p>
						<br>
						<font face="Oswald">Kredi yükleyen/magazadan alışveriş yapan bütün kullancılar şartları kabul etmiş sayılır.</font></p>
						<br>
						<font face="Oswald">Hesap güvenliği size aittir, hesap çalınırsa bundan MineTC sorumlu değildir.</font></p>
						<br>
						<font face="Oswald">Hile/Makro kullanmak yasaktır.</font><font face="Oswald" color="red">Ceza olarak 30 gün veya sınırsız sunucudan uzaklaştırılırsınız.</font></p>
						<br>
						<font face="Oswald">Din, dil, ırk vs. gibi konularda kişiye hakaret yasaktır.</font><font face="Oswald" color="red">Ceza olarak 30 gün veya sınırsız sunucudan uzaklaştırılırsınız.</font></p>
						<br>
						<font face="Oswald">Yetkilere hakaret etmek yasaktır.</font><font face="Oswald" color="red">Ceza olarak sınırsız sunucudan uzaklaştırılırsınız.</font></p>
						<br>
						<font face="Oswald">Kendini yetkili gibi veya yetkilinin yakın çevresindeymiş gibi tanıtmak yasaktır.</font><font face="Oswald" color="red">Ceza olarak sınırsız sunucudan uzaklaştırılırsınız.</font></p>
						<br>
						<font face="Oswald">Diğer oyuncuları çeşitli yollar ile kandırmak/dolandırmak yasaktır. </font><font face="Oswald" color="red">Ceza olarak 30 gun veya sınırsız sunucudan uzaklaştırılırsınız.</font></p>
						<br>
						<font face="Oswald">Başka sunucuların ip'lerini/linklerini paylaşmak yasaktır.</font><font face="Oswald" color="red">Ceza olarak sınırsız sunucudan uzaklaştırılırsınız.</font></p>
						<br>
						<font face="Oswald">Cinsiyet ayrımı yapmak/sözlü taciz/tahrik etmek yasaktır. </font><font face="Oswald" color="red">Ceza olarak sınırsız sunucudan uzaklaştırılırsınız.</font></p>
						<br>
						<font face="Oswald">Yetkilileri kandırmaya çalışmak yasaktır.</font><font face="Oswald" color="red">Ceza olarak sınırsız sunucudan uzaklaştırılırsınız.</font></p>
						<br>
						<font face="Oswald">Sunucuda siyaset etmek veya bir siyasi görüşe hakaret etmek yasaktır.</font><font face="Oswald" color="red">Ceza olarak 30 gun veya sınırsız sunucudan uzaklaştırılırsınız.</font></p>
						<br>
						<font face="Oswald">Sunucuda küfür etmek yasaktır.</font><font face="Oswald" color="red"> Ceza olarak 1 dakika ve 24 saat arası susturulursunuz.</font></p>
						<br>
						<font face="Oswald">Oyun içi hatalardan(bug) yararlanmak yasaktır.</font><font face="Oswald" color="red">Ceza olarak sınırsız sunucudan uzaklaştırılırsınız.</font></p>
						<br>
						<font face="Oswald">Sunucuda oynayan oyuncuları tehdit etmek yasaktır. </font><font face="Oswald" color="red">Ceza olarak 30 gun veya sınırsız sunucudan uzaklaştırılırsınız.</font></p>
						<br>
						<font face="Oswald">Sunucuyu kötülemek,sunucu hakkında yalan haber ortaya atmak yasaktır. </font><font face="Oswald" color="red">Ceza olarak sınırsız sunucudan uzaklaştırılırsınız.</font></p>
						<br>
						<font face="Oswald">VIP'lerin normal kişilerden bir farkı yoktur(Buradaki tüm kurallar sizlerdede geçerlidir). Diğer oyuncuları bu özellikle ile sözlü olarak ezmek veya hakaret etmek yasaktır.</font></p>
						<br>
						<font face="Oswald">Bir oyuncunun kişisel bilgilerini oyun içinden paylaşmak(ifşa etmek) yasaktır.</font><font face="Oswald" color="red">Ceza olarak 30 gun veya sınırsız sunucudan uzaklaştırılırsınız.</font></p>
						<br>
						<font face="Oswald">Güvenmediğiniz kişileri skype vs. üzerinden eklemeyiniz. Başınıza gelebileceklerden MineTC sorumlu değildir.</font></p>
						<br>
						<font face="Oswald">Yetkililer asla sizden şifrenizi,eşyalarınızı istemez. Bunu yapan kişiler</font><font face="Oswald" color="red">Ceza olarak sınırsız sunucudan uzaklaştırılırsınız.</font></p>
				    <br>
                    <br>
                    <br>
                </div>
            </div>
        </div>
		<?php

			include ('../right.php');

		include ('../footer.php');
        
	?>
    </div>
</body>
</html>
