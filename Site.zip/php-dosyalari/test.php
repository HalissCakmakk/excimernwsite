﻿
<form action="http://localhost/php-dosyalari/krediverkart.php" method="post">
<input type="text" name="user" value="FiratKayaHD">
<input type="text" name="credit" value="2">
<input type="text" name="telefon" value="5335953584">
<input type="text" name="guvenlik" value="token">
<input type="text" name="vipname" value="normalvip">
<input type="text" name="transid" value="111111">
<input type="submit" name="gonder" value="gonder">
</form>
