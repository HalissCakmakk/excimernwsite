﻿<?php

	include ('../ayarlar/ayar.php');	

	include ('../head.php');

?>
<body>
	<?php
		include('../logo.php');
	?>
    <div id="wrapper">
		<?php
			include ('../header.php');
		?>
        <div id="sol">
            <div class="icBaslik"><div class="icBaslikYazi"><i class="fa fa-users fa-3x"></i><font size="6"> YETKILIER</font></div></div>
            <div class="ic">
                <div class="indir">
                    <br>
                    <center>
						<img alt="Nahmut abi sendemi burdaydin?!?" style="border: 0px solid; border-radius: 4px;" src="http://cravatar.eu/avatar/KeremWhoTR/64.png"></p>
						<font face="Oswald" size="5px">KeremWhoTR</font></p><font face="Oswald" size="3px" color=red> KURUCU</font></p><br>
						<img alt="abi sendemi burdaydin?!?" style="border: 0px solid; border-radius: 4px;" src="http://cravatar.eu/avatar/ErenTC/64.png"></p>
						<font face="Oswald" size="5px">ErenTC</font></p><font face="Oswald" size="3px" color=red> KURUCU</font><p><br>
					<br>
                    </center>
                    <br>
                    <br>
                </div>
            </div>
        </div>
		<?php

			include ('../right.php');

		include ('../footer.php');
        
	?>
    </div>
</body>
</html>

