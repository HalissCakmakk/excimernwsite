﻿<center>
<div style="width: 50%; background-color: #ddd; height: 50%; font-family: Arial;">
<br><br>
<center>
<h1>Kredi Ver (Mobil)</h1>
<br><br>
<form action="http://localhost/php-dosyalari/kredivermobil.php" method="post">
<table>
	<tr>
		<td>Kullanici Ismi:</td>
		<td><input type="text" name="user" placeholder="Örn: KeremWho" /></td>
	</tr>
	<tr>
		<td>Verilecek Kredi:</td>
		<td><input type="text" name="credit" placeholder="Örn: 31" /></td>
	</tr>
	<tr>
		<td>Telefon No:</td>
		<td><input type="text" name="telefon" placeholder="Örn: 5313106231"/></td>
	</tr>
	<tr>
		<td>Guvenlik Kodu:</td>
		<td><input type="text" name="guvenlik" placeholder="Batihosttan Aldiginiz Kod"/></td>
	</tr>
	<tr>
		<td>Vip Ismi:</td>
		<td><input type="text" name="vipname" placeholder="Orn: IronVip"/></td>
	</tr>
	<tr>
		<td>TransID (Dokunma):</td>
		<td><input type="text" name="transid" value="111111"/></td>
	</tr>
	<tr>
		<td></td>
		<td><button type="submit" name="gonder" style="float: right;">Kredi Ver</button></td>
	</tr>
</table>
</form>
</div>
<div style="width: 50%; background-color: #ddd; height: 50%; font-family: Arial;">
<br><br>
<h1>Kredi Ver (Kart)</h1>
<br><br>
<form action="http://localhost/php-dosyalari/krediverkart.php" method="post">
<table>
	<tr>
		<td>Kullanici Ismi:</td>
		<td><input type="text" name="user" placeholder="Örn: KeremWho" /></td>
	</tr>
	<tr>
		<td>Verilecek Kredi:</td>
		<td><input type="text" name="credit" placeholder="Örn: 31" /></td>
	</tr>
	<tr>
		<td>Guvenlik Kodu:</td>
		<td><input type="text" name="guvenlik" placeholder="Batihosttan Aldiginiz Kod"/></td>
	</tr>
	<tr>
		<td>Vip Ismi:</td>
		<td><input type="text" name="vipname" placeholder="Orn: IronVip"/></td>
	</tr>
	<tr>
		<td>TransID (Dokunma):</td>
		<td><input type="text" name="transid" value="111111"/></td>
	</tr>
	<tr>
		<td></td>
		<td><button type="submit" name="gonder" style="float: right;">Kredi Ver</button></td>
	</tr>
</table>
</form>
</div>