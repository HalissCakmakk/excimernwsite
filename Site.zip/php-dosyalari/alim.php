<?php
	include ('../ayarlar/ayar.php');

	include ('../head.php');

?>
<body>
	<?php
		include('../logo.php');
	?>
    <div id="wrapper">
		<?php
			include ('../header.php');
		?>
        <div id="sol">
            <div class="icBaslik"><div class="icBaslikYazi"><i class="fa fa-envelope fa-3x"></i><font size="6"> ALIM</font></div></div>
            <div class="ic">
                <div class="indir">
                    <br>
                    <br>
                    <center>
					<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSdIVQw5O8LwOLt1VhdqAq4XGp4HMIcL5bGrm4R7MZszCIGN3w/viewform?embedded=true" width="760" height="500" frameborder="0" marginheight="0" marginwidth="0">Yükleniyor...</iframe>
                    </center>
                    <br>
                    <br>
                </div>
            </div>
        </div>
		<?php

			include ('../right.php');

		include ('../footer.php');
		
	?>
    </div>
</body>
</html>
