﻿<?php

	include ('../ayarlar/ayar.php');	

	include ('../head.php');

?>
<body>
	<?php
		include('../logo.php');
	?>
    <div id="wrapper">
		<?php
			include ('../header.php');
		?>
        <div id="sol">
            <div class="icBaslik"><div class="icBaslikYazi"><i class="fa fa-download fa-3x"></i><font size="6"> İNDİR</font></div></div>
            <div class="ic">
                <div class="indir">
                    <br>
                    <br>
                    <center>
                        <a target="_blank" href="https://yadi.sk/d/wiY06SHEmd7UU"><button type="submit" class="button-example-1 button-example-green" style="width: 220px; height: 50px;" value="Gönder" required><font size="5" face="Oswald"><i class="fa fa-download"></i> OYUNU İNDİR!</font></button></a>
                    </center>
                    <br>
                    <br>
                </div>
            </div>
        </div>
		<?php

			include ('../right.php');

		include ('../footer.php');
        
	?>
    </div>
</body>
</html>
