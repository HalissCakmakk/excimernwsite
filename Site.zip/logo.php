    <center>
        <div class="logo"><a href="<? echo $site_url ?>/index.php"><img src="<?php echo "$logo"; ?>" width="100%" alt="Site Logo"/></a></div>
    </center>