﻿<?php
header("Location:../bulunamadi/");
?>
