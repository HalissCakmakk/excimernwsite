<?php
header("Location:../bulunamadi/");
?>
